﻿using System;

namespace TestArgus
{
    public class Order
    {
        public int StartersCount { get; set; }
        public int MainsCount { get; set; }
        public int DrinksCount { get; set; }        
        public bool IsBefore1900 { get; set; }
    }

    public class PriceList
    {
        public decimal Starters { get; set; }
        public decimal Mains { get; set; }
        public decimal Drinks { get; set; }
        public decimal DrinkDiscount { get; set; }
        public decimal ServiceCharge { get; set; }
    }

    public class Bill
    {
        public decimal BillAmount { get; set; }
        public decimal BillWithDiscount { get; set; }
        public decimal Tips { get; set; }
    }

     public class CheckoutCalculations
    {
        
        private PriceList _priceList;
        public CheckoutCalculations(PriceList priceList)
        {
            _priceList = priceList; 
        }

        public Bill Calculate(Order order)
        {
            var totalFood = _priceList.Starters * order.StartersCount
                       + _priceList.Mains * order.MainsCount;

            var totalDrink = _priceList.Drinks * order.DrinksCount;

            var total = totalFood + totalDrink;

            var tip = totalFood * _priceList.ServiceCharge/100;

            var totalWithDrinkDiscount = totalFood + (totalDrink) * (100 -_priceList.DrinkDiscount)/100;

            return new Bill() { BillAmount = total, BillWithDiscount = totalWithDrinkDiscount, Tips = tip };
        }
    }
}
