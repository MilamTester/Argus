﻿using NUnit.Framework;
using System.Linq;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using TestArgus;

namespace TestArgusBdd.Steps
{
    [Binding]
    public sealed class CheckoutSteps
    {
       
        private CheckoutCalculations _calculator;
        private Order _order;
        private Bill _bill;
        private ScenarioContext _scenarioContext;

        public CheckoutSteps(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given(@"that price list is")]
        public void GivenThatPriceListIs(Table table)
        {
            var prices = table.CreateSet<PriceList>();
            _calculator = new CheckoutCalculations(prices!.First());
        }

        [When(@"the order is as following")]
        [When(@"the order is modified to")]    
        public void WhenTheOrderIsAsFollowing(Table table)
        {
            var orders  = table.CreateSet<Order>();

            _order = orders!.First();
        }

        [Then(@"Tips are (.*)")]
        public void ThenTipsAre(decimal tips)
        {
            _bill = _calculator.Calculate(_order);

            Assert.AreEqual(tips, _bill.Tips);
        }

        [Then(@"The bill is (.*)")]
        public void ThenTheBillIs(decimal billAmount)
        {
            _bill = _calculator.Calculate(_order);

            Assert.AreEqual(billAmount, _bill.BillAmount);
        }

        [Then(@"Total to pay is (.*)")]
        public void ThenTotalToPayIs(decimal total)
        {
            _bill = _calculator.Calculate(_order);
            ScenarioContext.Current["BillFor4"] = _bill.Tips + _bill.BillAmount;           
            Assert.AreEqual(total, _bill.Tips + _bill.BillAmount);
        }

        [Then(@"The bill after discount is (.*)")]
        
        public void ThenTheBillAfterDiscountIs(decimal total)
        {
            _bill = _calculator.Calculate(_order);
            ScenarioContext.Current["FirstBill"]= _bill.BillWithDiscount;
            Assert.AreEqual(total,  _bill.BillWithDiscount);
        }

        [Then(@"The final bill is (.*)")]
        public void ThenTheFinalBillIs(decimal totalAmount)
        {
            _bill = _calculator.Calculate(_order);
            var firsBill = (decimal)ScenarioContext.Current["FirstBill"];
            Assert.AreEqual(totalAmount, firsBill+ _bill.BillAmount+ _bill.Tips);
        }

        [When(@"more people made the order is as following")]
        public void WhenMorePeopleMadeTheOrderIsAsFollowing(Table table)
        {
            var orders = table.CreateSet<Order>();

            _order = orders!.First();
        }

      
    }
}
